/* eslint-disable no-unused-vars */

var require = {
	paths: {
		'qunit': [
			'../node_modules/qunitjs/qunit/qunit'
		]
	}
};
